﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Concept_WindowApp
{
    public partial class CalculatorApp : Form
    {
        public CalculatorApp()
        {
            InitializeComponent();
        }

        private void CalculatorApp_Load(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string result = "The Result is";
            int numOne = Convert.ToInt32(txtNoONe.Text.ToString());
            int numTwo = Convert.ToInt32(txtNoTwo.Text.ToString());

            lblResult.Visible = true;
            lblResult.Text  += Convert.ToString(numOne + numTwo);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
