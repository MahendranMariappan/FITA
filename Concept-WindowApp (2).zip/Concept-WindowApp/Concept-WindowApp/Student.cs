﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Concept_WindowApp
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }

        private void btnConnectToDB_Click(object sender, EventArgs e)
        {
            string connectString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=NetCourse;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection connection = null;
            string comtxt = "select * from dbo.Students";
            try
            {
                //Create and open a connection to SQL Server
                connection = new SqlConnection(connectString);
                connection.Open();

                SqlCommand command = new SqlCommand(comtxt, connection);
                SqlDataReader dataReader = command.ExecuteReader();

                //load into the result object the returned row from the database
                if (dataReader.HasRows)
                {
                    while (dataReader.Read())
                    {
                        string studName = Convert.ToString(dataReader["Name"]);
                    }
                }

                        //MessageBox.Show("Connected to Database");
                    }
            catch (Exception errMsg)
            {
                Console.WriteLine(errMsg.Message);
                MessageBox.Show(errMsg.Message);
            }
            finally
            {
                if(connection.State.ToString()=="Open")
                {
                    connection.Close();
                }
                    
            }
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            string name = Convert.ToString(txtName.Text);
            string email = Convert.ToString(txtEmail.Text);

            string connectString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=NetCourse;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection connection = null;
            string comtxt = "INSERT INTO [dbo].[Students] ([Name], [Email], [Phone], [Address], [Course]) VALUES ('{0}', '{1}', '9843222222', 'Velacherry', '.Net')";
            comtxt =string.Format(comtxt,name,email);
            try
            {
                //Create and open a connection to SQL Server
                connection = new SqlConnection(connectString);
                connection.Open();

                SqlCommand command = new SqlCommand(comtxt, connection);
                int resultCount = command.ExecuteNonQuery();
            }
            catch (Exception errMsg)
            {

            }
            finally
            {

            }

            }
    }
}
