﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Concept_WindowApp
{
    public partial class SecondForm : Form
    {
        public SecondForm()
        {
            InitializeComponent();
        }

        private void lblConnectDB_Click(object sender, EventArgs e)
        {
            string ConnectionString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = FITA; Integrated Security = True; Pooling = False";
            string strSql = "select * from  [dbo].[Students]";

            //Create the SQL Query for returning an article category based on its primary key
            //string sqlQuery = String.Format("select * from Article where ArticleID={0}", articleId);

            //Create and open a connection to SQL Server
            SqlConnection connection = new SqlConnection(ConnectionString);
            connection.Open();

            SqlCommand command = new SqlCommand(strSql, connection);

            SqlDataReader dataReader = command.ExecuteReader();

            //load into the result object the returned row from the database
            if (dataReader.HasRows)
            {
                while (dataReader.Read())
                {
                    string ArticleId = Convert.ToString(dataReader["StudentName"]);
                    //result.Body = dataReader["Body"].ToString();
                    //result.CategoryId = Convert.ToInt32(dataReader["CategoryID"]);
                    //result.PublishDate = Convert.ToDateTime(dataReader["PublishDate"]);
                    //result.Title = dataReader["Title"].ToString();
                }
            }
            //SqlConnection myConnection = new SqlConnection();
            //myConnection.ConnectionString = ConnectionString;
            //myConnection.Open();

            //SqlDataAdapter dadapter = new SqlDataAdapter();
            //dadapter.SelectCommand = new SqlCommand(strSql, myConnection);
            //DataSet dset = new DataSet();
            //dadapter.Fill(dset);
            ////myConnection.Close();
            //dataGridView1.DataSource = dset.DefaultViewManager;

            //Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = FITA; Integrated Security = True; Pooling = False
            // Create the connection.
            //using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connString))
            //{
            //    // Create a SqlCommand, and identify it as a stored procedure.
            //    using (SqlCommand sqlCommand = new SqlCommand("Sales.uspNewCustomer", connection))
            //    {
            //        sqlCommand.CommandType = CommandType.StoredProcedure;

            //        // Add input parameter for the stored procedure and specify what to use as its value.
            //        sqlCommand.Parameters.Add(new SqlParameter("@CustomerName", SqlDbType.NVarChar, 40));
            //        sqlCommand.Parameters["@CustomerName"].Value = txtCustomerName.Text;

            //        // Add the output parameter.
            //        sqlCommand.Parameters.Add(new SqlParameter("@CustomerID", SqlDbType.Int));
            //        sqlCommand.Parameters["@CustomerID"].Direction = ParameterDirection.Output;

            //        try
            //        {
            //            connection.Open();

            //            // Run the stored procedure.
            //            sqlCommand.ExecuteNonQuery();

            //            // Customer ID is an IDENTITY value from the database.
            //            this.parsedCustomerID = (int)sqlCommand.Parameters["@CustomerID"].Value;

            //            // Put the Customer ID value into the read-only text box.
            //            this.txtCustomerID.Text = Convert.ToString(parsedCustomerID);
            //        }
            //        catch
            //        {
            //            MessageBox.Show("Customer ID was not returned. Account could not be created.");
            //        }
            //        finally
            //        {
            //            connection.Close();
            //        }
            //    }
            //}
        }
    }
}
