﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ConceptThreading
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Main Thread Start");
            for (int a = 0; a < 5; a++)
            {
                Console.WriteLine("Method Main Thread" + a);
            }
            Thread newThread = new Thread(ConThread.MethodOne);
            //newThread = new Thread(ConThread.MethodSecond);
            newThread.IsBackground = false;
            //Foreground thread - by default fita2012
            //background thread
            newThread.Start();

            //Thread secondThread = new Thread(ConThread.MethodSecond);
            //secondThread.Start();  

            //ConThread.MethodOne();
            //ConThread.MethodSecond();
            Console.WriteLine("Main Thread End");
            Console.ReadLine();

        }
    }

   public static class ConThread
    {
       public static void MethodOne()
        {
            
           
            for (int a =0; a < 5; a++)
            {
                Console.WriteLine("Method One" + a);
            }
        }
       public static void MethodSecond()
        {
            for (int a =0; a < 5; a++)
            {
                Console.WriteLine("Method second" + a);
            }
        }
    }



    
}
